new fullpage('#fullpage', {
	autoScrolling:true,
	scrollHorizontally: true,
	navigation: true,
	anchors:['Num0', 'Num1', 'Num2', 'Num3', 'Num4'],
	afterLoad:function(old_elem, new_elem, direction){
		if(new_elem.index == 0) {
			sec0();
		}
		if(new_elem.index == 1) {
			sec1();
		}
		if(new_elem.index == 2) {
			sec2();
		}
		if(new_elem.index == 3) {
			sec3();
		}
		if(new_elem.index == 4) {
			sec4();  
		}
	}
});


// Section Function
function sec0(){
	//console.log('sec0');
	anime({
		targets: '.svg1 path',
		strokeDashoffset: [anime.setDashoffset, 0],
		easing: 'easeInOutSine',
		duration: 4000,
		delay: function(el, i) { return i * 400},
		direction: 'alternate',
		loop: true
	});
}

function sec1(){
	console.log('sec1');
}

function sec2(){
	console.log('sec2');
}

function sec3(){
	console.log('sec3');
}

function sec4(){
	console.log('sec4');
}


//탑메뉴
const Body = document.querySelector('body');
const Nav_Btn = document.querySelector('#nav_icon');

Nav_Btn.addEventListener('click', () =>{
	Body.classList.toggle('nav_active');
});